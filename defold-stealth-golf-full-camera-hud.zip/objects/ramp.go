components {
  id: "script"
  component: "/scripts/ramp.script"
}
components {
  id: "sprite"
  component: "/objects/pixel.sprite"
}
components {
  id: "collisionobject"
  component: "/objects/ramp.collisionobject"
}
