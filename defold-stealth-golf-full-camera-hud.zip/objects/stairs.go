components {
  id: "script"
  component: "/scripts/stairs.script"
}
components {
  id: "sprite"
  component: "/objects/pixel.sprite"
}
components {
  id: "collisionobject"
  component: "/objects/stairs.collisionobject"
}
