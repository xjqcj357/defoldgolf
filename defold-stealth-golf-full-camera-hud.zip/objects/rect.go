components {
  id: "sprite"
  component: "/objects/pixel.sprite"
}
components {
  id: "collisionobject"
  component: "/objects/rect.collisionobject"
}
