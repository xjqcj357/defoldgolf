components {
  id: "script"
  component: "/scripts/ball.script"
}
components {
  id: "sprite"
  component: "/objects/ball.sprite"
}
components {
  id: "collisionobject"
  component: "/objects/ball.collisionobject"
}
