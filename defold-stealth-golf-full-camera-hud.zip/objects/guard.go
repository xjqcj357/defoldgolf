components {
  id: "script"
  component: "/scripts/guard.script"
}
components {
  id: "sprite"
  component: "/objects/pixel.sprite"
}
