components {
  id: "sprite"
  component: "/objects/pixel.sprite"
}
