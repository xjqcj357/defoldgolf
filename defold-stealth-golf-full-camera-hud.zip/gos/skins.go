components {
  id: "gui"
  component: "/main/skins.gui"
}
