components {
  id: "gui"
  component: "/editor/editor.gui"
}
