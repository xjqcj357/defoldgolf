components {
  id: "script"
  component: "/scripts/controller.script"
}
