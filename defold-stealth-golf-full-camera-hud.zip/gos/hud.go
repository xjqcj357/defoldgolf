components {
  id: "gui"
  component: "/hud/hud.gui"
}
