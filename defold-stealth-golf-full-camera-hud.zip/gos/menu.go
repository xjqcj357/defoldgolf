components {
  id: "gui"
  component: "/main/menu.gui"
}
