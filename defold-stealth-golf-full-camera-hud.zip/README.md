# Mini Stealth Golf (Defold)
Open this folder in Defold and run. Window 1278x590. Menu + Skins, pull-back putting, walls/ground/hole, guards, ramps, stairs (multi-floor), and a simple editor.
